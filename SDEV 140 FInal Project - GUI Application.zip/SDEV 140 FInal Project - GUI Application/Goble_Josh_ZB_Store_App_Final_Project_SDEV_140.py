'''
Zimmer_Biomet_Store_Application_SDEV_140_Final_Project.py
    This application allows a user to log in using a provided guest account to demonstration what the application can do. It allows them to browse information about the company, product, 
    and allows them to order while confirming order was recieved.
    This program contains:
        -Classes
        -Functions with calls
        -Labels
        -Buttons
        -Entry Fields
        -Input Validation
        -Second Window Function
        -Images
        -Headers with information
        -Source Code Comments
        -Additional methods and functions not demostrated in class
    This program does NOT contain:
        -breezypythongui - This built in module does not contain functionality that can be used to create mulitiple frames and/or windows
    Joshua Goble 10/11/2023
    
    'IT JUST WORKS - Todd Howard'
'''
## Importing built in methods and modules to run program

import tkinter as tk                                                    # import tkinter
from tkinter import *                                                   # import libary functions and modules
from tkinter import Entry, Button, Label, Toplevel, messagebox, font    # importan various functions to be referenced
import re                                                               # import built-in package re for validation expressions

button_color = '#94b5eb'                                                # variable that holds the color chosen for button style
#foreground_color = '#######'                                           # variable that holds the color chosen for forground text color
window_bg_color = '#add1f0'                                             # variable that holds the color chosen for background color

##-----------------------------------------------------------------------------------------------------------##
## This class creates the default window that holds the frames that are switched between each other
##-----------------------------------------------------------------------------------------------------------##

class windows(tk.Tk):
    def __init__(self, *args, **kwargs):                                # __init__ method declared within the class that initializes the attributes of the object             
        tk.Tk.__init__(self, *args, **kwargs)                           # __init__ method declared within the super class so there can be multiple inheritance for child class
        self.wm_title("ZB Store App")                                   # Adding a title to the window
        container = tk.Frame(self, height=600, width=600)               # Creating a frame and assigning it to container
        self.resizable(0, 0)                                            # Sets the window to be unable to be resized
        self.geometry('600x600')                                        # Sets the window to a certain size due to the style of window and how the widgets are set up
        container.pack(side="top", fill="both", expand=True)            # specifying the region where the frame is packed in root
        container.grid_rowconfigure(0, weight=1)                        # configuring the location of the container using grid
        container.grid_columnconfigure(0, weight=1) 
        self.frames = {}                                                # We will now create a dictionary of frames
# we'll create the frames themselves later but let's add the components to the dictionary.
        for F in (LogInPage, MainPage, OrderPage, ProductPage):         # For Loop that allows switch of classes | This was a method that I aquired help with. This was beyond my skill before the project 
            frame = F(container, self)                                  # Sets the variable as the current container
# the windows class acts as the root window for the frames.
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")                  # Assigns position of class within the frame
        self.show_frame(LogInPage)                                      # method to switch frames
# Function that is called to switch frames
    def show_frame(self, cont):                                         # Callable Function
        frame = self.frames[cont]
# raises the current frame to the top
        frame.tkraise()

##--------------------------------------------------------------------------------------------------------------------------------------------------##
## This Class creates the Log In window | This window uses a Guess Account for demostration. This window can not be reentered once the page is left.
### For a normal application, you can log out but for this final project, such a function is left out on purpose.
##--------------------------------------------------------------------------------------------------------------------------------------------------##

class LogInPage(tk.Frame):                                              # Class that holds Log in Page with function, banner, button, quit button, validation for Guest account
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller                                    # Reference for the log in validation method
        self.configure(bg=window_bg_color)                              # This sets the background to the style color chosen for application
# Debug Statement 
        #print(font.nametofont('TkTextFont').actual()) #command to find what font is used
# This creates a frame for application 
        frame1 = tk.Frame(self, bg='white', highlightbackground="black", highlightthickness=1)           # Frame, white background, border drawn
        self.image_MainBanner = tk.PhotoImage(file='zimmer_banner_1.png')                                # Banner image for application aesthetic
        self.labelMainBanner = tk.Label(frame1, image=self.image_MainBanner, width=600, height=145)      # Banner image for application aesthetic
        self.labelMainBanner.pack(side='top')                                                            # Banner is packed to top of application window
        frame1.pack()                                                                                    # Banner Frame is packed
# Creates a frame to hold widgets, centers widgets for aesthetic purposes      
        frame_main = tk.Frame(self, bg=window_bg_color, highlightbackground="black", highlightthickness=1) 
        frame2 = tk.Frame(frame_main, bg='white', highlightbackground="black", highlightthickness=1)
# Creates labels that contain text and images for class
        label = tk.Label(frame2, text="Zimmer Biomet Application Log In", bg='#94b5eb', font=('Segoe UI', 17), highlightbackground="black", highlightthickness=1)
        label.pack(padx=10, pady=10)
# This creates a tk entry and variable that is stored and called back. The entry has default text that will dissappear if the user clicks within the entry box
        self.username_entry = tk.StringVar()                                                             # takes the string value from entry 
        UserLogIn = tk.Entry(frame2, textvariable=self.username_entry, width=25) # takes input from user to insert username
        UserLogIn.insert(tk.END, "Guest")                                                                # setting insert as guest for log in purposes | can be used as default text for username
        UserLogIn.bind("<Button-1>", lambda e: UserLogIn.delete(0, tk.END))                              # event that deletes text in username entry box when selected
        UserLogIn.pack(padx=3, pady=8)
# This creates a tk entry of password entry field and variable that is stored and called back. The entry has default text that will disappear if the user clicks within the entry box. The text is hidden by default.     
        self.password_entry = tk.StringVar()                                                             # takes the string value from entry 
        PassLogIn = tk.Entry(frame2, textvariable=self.password_entry, show='*', width=25)               # takes input from user to insert password while concealing the text value
        PassLogIn.insert(tk.END, "Guest")                                                                # setting insert as guest for log in purposes | can be used as default text for password
        PassLogIn.bind("<Button-1>", lambda e: PassLogIn.delete(0, tk.END))                              # event that deletes text in password entry box when selected
        PassLogIn.pack(padx=5, pady=8)
# This creates a tk button that calls the Log In Validation function to verify that the credentials of the guest account are correct | Will not allow the user to log in without the guess account for demostration
        switch_window_button = tk.Button(frame2, text='Log In', width=17, bg=button_color, command=self.LogIn_Validation)
        switch_window_button.pack(padx=3, pady=10)
        frame2.pack(pady=80, anchor='center') 
# This creates a tk button that calls the quit function to exit the application
        button_quit = tk.Button(frame2, text = 'Quit', fg='red', bg=button_color, command = quit)        # quit button for application
        button_quit.pack(side='bottom', padx=10, pady=10)
        frame_main.pack(expand=True, fill='both')                                                        # This packs the main frame in the log in application window

###----------------------------------------------------------------------------------------------------------------------------###
### For this project, the scope of the log in validation and accounts have been reduced. 
### Normally, many accounts can be logged in but for the sake of this project, 
### only guest account provided by the "sales person" such as the Guest account can be used as mentioned in the user manual
###-----------------------------------------------------------------------------------------------------------------------------###

# This function validates that the guest account has been used and allows the application to be logged into

    def LogIn_Validation(self):
        username_entry = self.username_entry.get()                                                       # callback function that collects the username value as a string that sets the variable
        password_entry = self.password_entry.get()                                                       # callback function that collects the password value as a string that sets the variable
        if username_entry =='Guest' and password_entry =='Guest':                                        # if condition to check if it matches and allows the program to contiune
            self.controller.show_frame(MainPage)                                                         # sets controller to show MainPage class as the current frame
        else:
           messagebox.showerror("Error", 'Guest account is required for demonstration.')                 # error statement if the guest account information isn't entered correctly

##-----------------------------------------------------------------------------------------------------------------------------------------------------##
## This class creates the MainPage frame  
## Information only page with buttons that leads to product page, order page, and quit button with a banner label at top for asethetic purposes
## This page demonstrates the company name, mission purposes and guiding principles, and goal for their patients
##-----------------------------------------------------------------------------------------------------------------------------------------------------##

class MainPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.configure(bg=window_bg_color)                                                               #  sets current window to the window background color for aesthetic purposes
# This frame sets up the banner frame for the current application window, banner is set to the top with a black border line       
        frame_banner = tk.Frame(self, bg=window_bg_color, highlightbackground="black", highlightthickness=1)
        self.image_MainBanner = tk.PhotoImage(file='zimmer_banner_2.png')                                # banner application set to variable
        self.labelMainBanner = tk.Label(frame_banner, image=self.image_MainBanner, width=600, height=145)# banner for application
        self.labelMainBanner.pack(side='top')                                                            # banner is packed at top
        frame_banner.pack()
# This frame sets up the  main frame for the window, the label frame that contains company information and formats the frames within while adding style to the text and borders for aesthetic purposes
        main_frame = tk.Frame(self, bg=window_bg_color, highlightbackground="black", highlightthickness=1)
        frame_label = tk.Frame(main_frame, bg='white', highlightbackground="black", highlightthickness=1)
# These are labels that display the company name, mission statements, text about guiding principles, and history
# Every label is packed to move from top to bottom, add small space to create even spacing, and various styles of font, color, and borderlines to make it appealing to the eyes and maintain aesthetic with rest of program
        label = tk.Label(frame_label, text='Zimmer Biomet', highlightbackground='black', highlightthickness=1, bg=window_bg_color, justify='center', font=('times new roman', 18))
        label.pack(padx=0, pady=3)
        label = tk.Label(frame_label, bg='white', text='Our Mission', fg='#94b5eb', justify='center', font=('Segoe UI', 15))
        label.pack(padx=0, pady=0)
        label = tk.Label(frame_label, bg='white', text='"Alleviate pain and improve the quality of life for people around the world"', bd=2, justify='center', font=('Segoe UI', 12))
        label.pack(padx=0, pady=0)
        label = tk.Label(frame_label, bg='white', text='Our Mission and Guiding Principles', fg='#94b5eb', justify='center', font=('Segoe UI', 15))
        label.pack(padx=0, pady=0)
# This label explains the company history, text is set to have a new line about every 60 or so characters which gives it a appealing pyramid look to the text with the final line standing out on purpose
        label = tk.Label(frame_label, text="Zimmer Biomet has been based in Warsaw since it was founded in 1927.\n \
Today, Zimmer Biomet has operations in more than 25 countries around\n \
the world and sells products in more than 100 countries. \
For nearly 90 years,\n Zimmer Biomet has been a driving force in the rapidly \
growing musculoskeletal \n healthcare industry. \
With an unwavering focus on the needs of patients and surgeons,\n \
Zimmer Biomet is an industry leader.", bg='white', bd=0, justify='center', relief='flat', font=('Segoe UI', 9))
        label.pack(padx=0, pady=0)        
        label = tk.Label(frame_label, bg='white', text='Guiding Prinicple', fg='#94b5eb', justify='center', font=('Segoe UI', 15))
        label.pack(padx=0, pady=0)
# This label showcases the company's goals and commitment to integrity
        label = tk.Label(frame_label, bg='white', text='Respect the contributions and perspectives of all Team Members.\n \
Strive for the highest standards of patient safety, quality and integrity.\n \
Focus our resources in areas where we will make a difference\n \
Ensure the company’s return is equivalent to the value we provide our customers and patients.\n \
Give back to our communities and people in need.', justify='center', font=('Segoe UI', 9))
        label.pack(padx=0, pady=0)
        frame_label.pack(padx=0, pady=35)
# This frame creates a bottom frame that contains the buttons to switch pages and/or quit the program. The buttons maintain the same position throughout the program and maintains placement for each page        
# We use the switch_window_button in order to call the show_frame() method as a lambda function
# The buttons use the command to switch pages and the quit button uses the quit function to exit program
        frame_button = tk.Frame(main_frame, bg=window_bg_color)
        switch_window_button = tk.Button(frame_button, text="Go to the Product Page", width=17, bg=button_color, command=lambda: controller.show_frame(ProductPage),)
        switch_window_button.pack(side="left")
        switch_window_button = tk.Button(frame_button, text="Go to the Order Page", width=17, bg=button_color, command=lambda: controller.show_frame(OrderPage),)
        switch_window_button.pack(side="right")
        self.button_quit = tk.Button(frame_button, text = 'Quit', fg='red', bg=button_color, command = self.quit)                # quit button for application
        self.button_quit.pack(side='bottom', padx=5)                                                                             # quit button contain red text to differentiate from other buttons
        frame_button.pack(side='bottom', pady=2)                                                                                 # frame is packed at bottom
        main_frame.pack(expand=True, fill='both')                                                                                # main frame is packed at end to contain all other frames

##-----------------------------------------------------------------------------------------------------------------------------------------------------##
## This class creates the ProductPage class which holds information about available product, only four products are shown as a demonstration currently with more added lately of application is approved
## The frame contains frames with text, images, and banner which color style carrying over for aesthetic purposes
## Product is labeled on page so the Guest can order product shown in demonstration to ensure program runs as intended
##-----------------------------------------------------------------------------------------------------------------------------------------------------##

class ProductPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.configure(bg=window_bg_color)
# This frame contains the banner and is packed at the top 
        frame_banner = tk.Frame(self, highlightbackground="black", highlightthickness=1)                                         # Banner frame has drawn borderline
        self.image_MainBanner = tk.PhotoImage(file='zimmer_banner_3.png')                                                        # Each banner contains a different image at comparable sizes
        self.labelMainBanner = tk.Label(frame_banner, image=self.image_MainBanner, width=600, height=145)                        # banner for application
        self.labelMainBanner.pack(side='top')                                                                                    # Banner is packed at top for each frame
        frame_banner.pack(side='top')
# This frame creates the main containing frame for all child frames, This frame uses the window background variable with drawn borderlines
        main_frame = tk.Frame(self, bg=window_bg_color, highlightbackground="black", highlightthickness=0.5)
# This frame creates the bottom frame for page and quit buttons, this frame is carried over to each page so it maintains style and aesthetic while maintaining same position throughout pages
        frame_bottom = tk.Label(main_frame, bg=window_bg_color, width=600, height=80)                                            # background set to window background variable to maintain color theme
        frame_button = tk.Frame(frame_bottom, bg=window_bg_color)
        switch_window_button = tk.Button(frame_button, text="Go to the Main Page", width=17, bg=button_color, command=lambda: controller.show_frame(MainPage),)   # command to switch pages
        switch_window_button.pack(side="left")
        switch_window_button = tk.Button(frame_button, text="Go to the Order Page", width=17, bg=button_color, command=lambda: controller.show_frame(OrderPage),) # command to switch pages
        switch_window_button.pack(side="right")
        self.button_quit = tk.Button(frame_button, text = 'Quit', fg='red', bg=button_color, command = self.quit)                                                 # quit button for application
        self.button_quit.pack(side='bottom', padx=5)
        frame_button.pack(side='bottom')                                                                                                                          # button frame is packed before bottom frame
        frame_bottom.pack(side='bottom', expand=True, fill='both',  padx=0, pady=0)                                                                               # button frame is packed after button frame to contain frame
# This frame creates the frame that contains image frame and description frame, it uses a white background with drawn borderlines
        frame_product = tk.Frame(main_frame, bg='white', highlightbackground="black", highlightthickness=1)
# This label uses \n to move text to next line so it doesn't run past drawn borderlines while maintaining a pyramid shape that is appealing to the eyes for aesthetic purposes
        label_desc = tk.Label(frame_product, text="Zimmer Biomet offers surgeons a expansive technology portfolio that includes the lastest innovations in \n \
biological limb replacement that includes products like total knee systems and revision knee systems, \n \
hip products, shoulder replacement systems, along with foot and ankle solutions to \n \
better alleviate pain and improve your quality of life.", bg='white')
        label_desc.pack(side='bottom')
# This label uses \n to move text to next line so it doesn't run past drawn borderline while maintaining a pyramid shape that is appealing to the eyes for aesthetic purposes, white background
        label_text_banner = tk.Label(frame_product, text='We seamlessly transform the patient experience through our innovative products \n \
and suite of integrated digital and robotic technologies that \n \
leverage data, data analytics and artificial intelligence.', fg=button_color, bg='white', highlightbackground="black", highlightthickness=0, font=('Segoe UI', 12))
        label_text_banner.pack(side='top', expand=True, fill='both')
# This frame creates the label frame for product labels and image frames so it can be packed to be appealing to look at while maintaining a professional style      
        frame_product_label = tk.Label(frame_product, bg='white')
# This label creates a label that contains a title and image demonstrating what a shoulder prosthetic looks like
        frame_product_label_shoulder = tk.Label(frame_product_label, bg='white', highlightbackground="black", highlightthickness=1)                             
        frame_shoulder_label = tk.Label(frame_product_label_shoulder, text='Shoulder', bg=window_bg_color, highlightbackground="black", highlightthickness=1)   # creates a product title label
        frame_shoulder_label.pack(side="top", fill='both')                                                                                                      # packs title to the top of anchor
        self.image_shoulder = tk.PhotoImage(file='shoulder.png')                                                                                                # sets image as variable to be called in label
        self.imageShoulder = tk.Label(frame_product_label_shoulder, bg='white', image=self.image_shoulder, width=120, height=150)                               # creates label and contains called image variable
        self.imageShoulder.pack(side="bottom")                                                                                                                  # packs image towards the bottom
        frame_product_label_shoulder.pack(side='left')                                                                                                          # packs shoulder image and label to the leftmost spot
# This label creates a label that contains a title and image demonstrating what a totle knee prosthetic looks like
        frame_product_label_knee = tk.Label(frame_product_label, bg='white', highlightbackground="black", highlightthickness=1)                                 # creates a anchor label
        frame_knee_label = tk.Label(frame_product_label_knee, text='Total Knee', bg=window_bg_color, highlightbackground="black", highlightthickness=1)         # creates a product title label
        frame_knee_label.pack(side='top', fill='both')                                                                                                          # packs title to top of anchor
        self.image_knee = tk.PhotoImage(file='knee.png')                                                                                                        # sets image as variable to be called in label
        self.imageKnee = tk.Label(frame_product_label_knee, bg='white', image=self.image_knee, width=120, height=150)                                           # creates label and contains called image variable
        self.imageKnee.pack(side="bottom")                                                                                                                      # packs image towards the bottom
        frame_product_label_knee.pack(side='left')                                                                                                              # packs knee image and label to the left of center spot
# This label creates a label that contains a title and image demonstrating what a hip stem prosthetic looks like
        frame_product_label_hip = tk.Label(frame_product_label, bg='white', highlightbackground="black", highlightthickness=1)                                  # creates a anchor label
        frame_hip_label = tk.Label(frame_product_label_hip, text='Hip Stem', bg=window_bg_color, highlightbackground="black", highlightthickness=1)             # creates a anchor label
        frame_hip_label.pack(side='top', fill='both')                                                                                                           # packs title to the top of anchor
        self.image_hip = tk.PhotoImage(file='hip.png')                                                                                                          # sets image as variable to be called in label
        self.imageHip = tk.Label(frame_product_label_hip, bg='white', image=self.image_hip, width=120, height=150)                                              # creates label and contains called image variable
        self.imageHip.pack(side="bottom")                                                                                                                       # packs image towards the bottom
        frame_product_label_hip.pack(side='right')                                                                                                              # packs hip image and label to the right of center spot
 # This label creates a label that contains a title and image demonstrating what a ankle prosthetic looks like       
        frame_product_label_ankle = tk.Label(frame_product_label, bg='white', highlightbackground="black", highlightthickness=1)                                # creates a anchor label
        frame_ankle_label = tk.Label(frame_product_label_ankle, text='Ankle', bg=window_bg_color, highlightbackground="black", highlightthickness=1)            # creates a anchor label
        frame_ankle_label.pack(side='top', fill='both')                                                                                                         # packs title to the top of anchor
        self.image_ankle = tk.PhotoImage(file='ankle.png')                                                                                                      # sets image as variable to be called in label
        self.imageAnkle = tk.Label(frame_product_label_ankle, bg='white', image=self.image_ankle, width=120, height=150)                                        # creates label and contains called image variable
        self.imageAnkle.pack(side="bottom")                                                                                                                     # packs image towards the bottom
        frame_product_label_ankle.pack(side='right')                                                                                                            # packs abkle image and label to the rightmost spot
        frame_product_label.pack(fill='x')                                                                                                                      # packs the product label frame 
        frame_product.pack(expand=True, fill='both', padx=10, pady=60)                                                                                          # packs the prduct frame cointaining the label frame
        main_frame.pack(expand=True, fill='both')                                                                                                               # packs the main frame containing all the other frames
##-----------------------------------------------------------------------------------------------------------------------------------------------------##
## This class creates the OrderPage for the application and window frame.It contains entry fields that asks for contact information so the user can request product through the application
## It opens it as the standard size with a banner, buttons, labels, and entry fields. It also has a function in the order button that opens a order confirmation window that calls back entry fields and displays mesages.
## The product request function will open the secondary window, giving it a slightly different look in order to catch the users attention more directly just to confirm they seen it.
##-----------------------------------------------------------------------------------------------------------------------------------------------------##

### No doubt this could look cleaner and function smoother but with time constrains, I wasn't able to get it to validate without having some issues. I elected to take a easier and less time consuming method that doesn't look as clean with a lot of variables and if/else statements placed in a single function

class OrderPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.configure(bg='light blue')
# This function clears the entry fields when called        
        def clear_fields():
            self.entry.delete(0, END)
# This function will create a new window that contains the name, contact details, and requests items from the application while displaying additional information for the user
# It does not contain a banner, the aesthetic is slightly off compared to the rest of the application as it is more focused on displaying important information about a order than describing items or the company
        def product_request(entry_FName, entry_Address, entry_Zip, entry_Email, entry_Phone, entry_shoulder, entry_hip, entry_knee, entry_ankle):               # entry fields values are requested in this function
# these variables function the same as the pervious variables in the other classes but it opens a new window along with the order and contact details
            order_window = Toplevel()                                                                                                                           # this opens the new window 
            order_window.geometry('800x500')                                                                                                                    # forces window to a shorter but wider size
            order_window.title('Confirmation Window')                                                                                                           # sets title for new window
            order_window.configure(bg=window_bg_color)                                                                                                          # carries over the same window background
            order_window.resizable(0,0)                                                                                                                         # forces window to be non-resizeable
### The below code contains many repeated lines to redisplay information from the order page, bare with me ###
# This creates a label that is center as the title of the page while holding the same color and style as previous windows with a drawn border
            label_title = tk.Label(order_window, highlightbackground="black", highlightthickness=1, bg=button_color, font=('Segoe UI', 16, 'bold'), text='Order Details')
            label_title.pack(padx=10, pady=(40, 0))
# This creates the frame for the confirmation text, below the title label to force the details lower down, adding in space while having larger than normal font, drawn background, and different background color
            frame_desc = tk.Frame(order_window, highlightbackground="black", highlightthickness=1, bg=button_color)
# This label is embedded in the desc frame, packed to the top of that frame but below the title label. It contains additional info for user while maintaining the app aesthetic and drawn background
            label_desc = tk.Label(frame_desc, highlightbackground="black", highlightthickness=1, bg='white', font=('Segoe UI', 10), text='Thank you for ordering from out product line. Below is the requested order with your contact information. \n A sales person will reach out to you to contiune to the next stage of your order!')
            label_desc.pack(padx=5, pady=5, expand=True, fill='both')                                                 # this packs the label within the desc frame above the order frame
            frame_desc.pack(padx=10, pady=10, side='top', expand=True, fill='x',)                                     # this packs the frame so the disclaimer frame can be created at the bottom of the window
# This creates the frame for the disclaimer label, this frame is called due to pack() functioning a certain way. If this is created AFTER the order frame, it will place it between them. The frame is ordered in a way while using the side attrib in a way of declaring what space they will take up like in a order of operations math question
            frame_disclaimer = tk.Frame(order_window, highlightbackground="black", highlightthickness=1, bg=button_color)
# This creates a label disclaiming that additional implant size information may be required if any patients don't conform to size charts  
            label_disclaimer = tk.Label(frame_disclaimer, highlightbackground="black", highlightthickness=1, bg='white', font=('Segoe UI', 9, 'italic'), text='Prosthesis implants conform to size charts generated from collected client data and patient measurements. \n If a custom made prosthesis is required, inform sales person of needed adjustments.')
            label_disclaimer.pack(padx=5, pady=5, expand=True, fill='x')                                              # this packs the label into the disclaimer frame
            frame_disclaimer.pack(padx=5, pady=5, side='bottom', expand=True, fill='x')                               # this packs the frame towards the bottom of the frame
# This creates the main contact frame that will contain the other contact frames, it is created with a white background and drawn broder
            frame_contact = tk.Frame(order_window, highlightbackground="black", highlightthickness=1, bg='white')
# This creates the left contact frame that will contain the contact labels to be displayed for the user to confirm their information matches what they insterted, it is created with a white background and drawn border
            frame_contact_left = tk.Frame(frame_contact, highlightbackground="black", highlightthickness=1, bg='white')
# These labels are created to declare what information was entered so the user can be contacted
            label_name = tk.Label(frame_contact_left, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text='Contact Name: ')
            label_name.pack(padx=5, pady=5, expand=True, fill='x')            
            # label
            label_email = tk.Label(frame_contact_left, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text='Contact Email: ')
            label_email.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_phone = tk.Label(frame_contact_left, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text='Contact Phone Number:')
            label_phone.pack(padx=5, pady=5, expand=True, fill='x')                                                                                               
            # end of labels for this frame
            frame_contact_left.pack(padx=0, pady=0, side='left', expand=True, fill='both')                            # this packs the label frame to the left
# This creates the right contact frame that will contain the text displayed what the user entered, it calls the variable and displays as a string, created with a background window color and drawn border
            frame_contact_right = tk.Frame(frame_contact, highlightbackground="black", highlightthickness=1, bg='white' )
# This creates labels that calls the entry variable and displays as a string, this could be added to a list or function in a smoother manner but I ran out of time, this carry over a different aesthetic, intended to pop out differently compared to rest of application
            label_name_contact = tk.Label(frame_contact_right, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text=entry_FName)
            label_name_contact.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_email_contact = tk.Label(frame_contact_right, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text=entry_Email)
            label_email_contact.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_phone_contact = tk.Label(frame_contact_right, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text=entry_Phone)
            label_phone_contact.pack(padx=5, pady=5, expand=True, fill='x')
            ## end of labels for this frame
            frame_contact_right.pack(padx=0, pady=0, side='right', expand=True, fill='both')                          # packs the entry frame to the right of the label frame
            ## end of frames for contact info
            frame_contact.pack(padx=5, pady=5, side='left', expand=True, fill='both')                                 # packs to the left of the two middle frames 
# This creates a main frame for the order information that will contain order information for user, it is created with a white background and drawn border
            frame_order = tk.Frame(order_window, highlightbackground="black", highlightthickness=1, bg='white')
# This creates the left order frame where it contains labels to display to the user what product was ordered, it is created with a white background and a drawn border
            frame_order_left = tk.Frame(frame_order, highlightbackground="black", highlightthickness=1, bg='white')
# This set of code creates the labels that displays to the user what product they have ordered, it was intended to be different enough to catch the user's eye when the window appears with a different aesthetic
            label_shoulder_order = tk.Label(frame_order_left, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text='Shoulders Needed: ')
            label_shoulder_order.pack(padx=5, pady=5, expand=True, fill='x')            
            # label
            label_hip_order = tk.Label(frame_order_left, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text='Hip Stems Needed: ')
            label_hip_order.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_knee_order = tk.Label(frame_order_left, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text='Total Knees Needed:')
            label_knee_order.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_ankle_order = tk.Label(frame_order_left, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text='Ankles Needed:')
            label_ankle_order.pack(padx=5, pady=5, expand=True, fill='x')
            ## end of labels for this frame
            frame_order_left.pack(padx=0, pady=0, side='left', expand=True, fill='both')                              # packs to the left of the order frames
# This creates the right order frame where it contains labels to display the numeral value of what they ordered, it calls the variables of the entry fields and displays them as text 
            frame_order_right = tk.Frame(frame_order, highlightbackground="black", highlightthickness=1, bg='white' )
# This creates the labels that calls the entry variables and displays them as a string for the user. Very messy but time restrains and all that. It carries a different aesthetic for reasons already announced
            label_shoulder_order = tk.Label(frame_order_right, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text=entry_shoulder)
            label_shoulder_order.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_hip_order = tk.Label(frame_order_right, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text=entry_hip)
            label_hip_order.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_knee_order = tk.Label(frame_order_right, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text=entry_knee)
            label_knee_order.pack(padx=5, pady=5, expand=True, fill='x')
            # label
            label_ankle_order = tk.Label(frame_order_right, highlightbackground="black", highlightthickness=1, bg=window_bg_color, font=('Segoe UI', 9, 'bold'), text=entry_ankle)
            label_ankle_order.pack(padx=5, pady=5, expand=True, fill='x')   
            ## end of labels for this frame
            frame_order_right.pack(padx=0, pady=0, side='right', expand=True, fill='both')                           # this packs the to the right of the entry label frame
            ## end of frames for this order info
            frame_order.pack(padx=5, pady=5, side='right', expand=True, fill='both')                                 # this packs the product order frame to the right of the the two middle frames

###-----------------------------------------------------------------------------------------------------------------------------------------------------###
### This is the end of the order information frames, it was intended to look the same as the other windows in the application but as it was being created, someone said it look out of place and called attention to the information displayed so it was carried over in the final product as a feature of the window 
### Some help was aquired when doing the validation function, Re is called to validate formatting of the strings to make sure they match what should be entered into the entry fields
### If the user inputs something wrong, the label will flash red for 5 seconds before becoming black again while a empty label will configure to display red error text before becoming empty again
### This was intended to ensure almost complete validation for the user and application as sales people are hard to contact currently
### One note, due to the use of if elif else statements, it displays red down the list of labels if multiple entry fields are incorrectly starting with the top most label. This can be fixed with better code but time restrains. 
### I write these in as notes for later on when I review these as I learn to better code.
###-----------------------------------------------------------------------------------------------------------------------------------------------------###

# This function calls get() function to collect values within the entry fields, it validates them again if, else, else if statements till the correct input is taken and opens a new window containing select info
# It displays labels as red to indicate what entry field is incorrect with a displayed error message to encompany it
# The entry fields contain default text for the user to mimic their syntax in order to make sure validation is succuessful, default text is not accepted and will disappear when selected



        def order_validation():
            phone_pattern = re.compile(r"^\d{3}-\d{3}-\d{4}$")                                                        # this sets the variable as a method of the re module, setting a pattern to be checked for validation. It doesn't include .com for a reason I forgot. Could be fixed before a actual final release of application
            email = entry_Email.get()                                                                                 # email variable is set as .get() string for re.match method validation
            phone_number = entry_Phone.get()                                                                          # see above for phone number validation
            
            if entry_FName.get() == '' or entry_FName.get().isdigit() or entry_FName.get() == '"Last, First"':        # if the entry field is empty, containing a number, and/or containing default text, it will display a error
                label_warning.config(text='Invalid Name')                                                             # warning label is set to display this error message
                label_FName.config(fg='red')                                                                          # turns entry label foreground (text) as red to "pop"
                label_FName.after(5000, on_after)                                                                     # turns entry label text back to black after 5 seconds 
            
            elif entry_Address.get() == '' or entry_Address.get() == '"Street, City, State"':                         # if entry field is empty or containing default text, it will pop up as a error with red label and warning
                label_warning.config(text='Invalid Address')                                                          # warning label is set to display this error message
                label_Address.config(fg='red')                                                                        # turns entry label foreground (text) as red to "pop"
                label_Address.after(5000, on_after)                                                                   # turns entry label text back to black after 5 seconds 
            
            elif entry_Zip.get() == '' or not entry_Zip.get().isdigit() or (len(entry_Zip.get()) != len("12345")):    # if entry field is empty, containing a letter, or doesn't match standard zip length, it will pop a error and display warning and red label
                label_warning.config(text='Invalid Zip')                                                              # warning label is set to display this error message
                label_Zip.config(fg='red')                                                                            # turns entry label foreground (text) as red to "pop"
                label_Zip.after(5000, on_after)                                                                       # turns entry label text back to black after 5 seconds 
            
            elif entry_Email.get() == '' or not re.match(r"^[A-Za-z0-9\.\+_-]+@[A-Za-z0-9\._-]+\.[a-zA-Z]*$", email): # if the email is empty or variable string doesn't contain a @ and a period, it will pop a error and display a warning and red label
                label_warning.config(text='Invalid Email')                                                            # warning label is set to display this error message
                label_Email.config(fg='red')                                                                          # turns entry label foreground (text) as red to "pop"
                label_Email.after(5000, on_after)                                                                     # turns entry label text back to black after 5 seconds 
            
            elif entry_Phone.get() == '' or not phone_pattern.match(phone_number):                             # if the entry field is empty or doesn't match standard phone number format, it will pop a error and display a red label and warning
                label_warning.config(text='Invalid Phone #')                                                   # warning label is set to display this error message
                label_Phone.config(fg='red')                                                                   # turns entry label foreground (text) as red to "pop"
                label_Phone.after(5000, on_after)                                                              # turns entry label text back to black after 5 seconds 
            
            elif entry_shoulder.get() == '' or not entry_shoulder.get().isdigit():                             # if entry is empty or isn't a digit, it will pop a error and display a red label and warning
                label_warning.config(text='Invalid Entry')                                                     # warning label is set to display this error message
                label_shoulder.config(fg='red')                                                                # turns entry label foreground (text) as red to "pop"
                label_shoulder.after(5000, on_after)                                                           # turns entry label text back to black after 5 seconds 
            
            elif entry_hip.get() == '' or not entry_hip.get().isdigit():                                       # if entry is empty or isn't a digit, it will pop a error and display a red label and warning
                label_warning.config(text='Invalid Entry')                                                     # warning label is set to display this error message
                label_hip.config(fg='red')                                                                     # turns entry label foreground (text) as red to "pop"
                label_hip.after(5000, on_after)                                                                # turns entry label text back to black after 5 seconds 
            
            elif entry_knee.get() == '' or not entry_knee.get().isdigit():                                     # if entry is empty or isn't a digit, it will pop a error and display a red label and warning
                label_warning.config(text='Invalid Entry')                                                     # warning label is set to display this error message
                label_knee.config(fg='red')                                                                    # turns entry label foreground (text) as red to "pop"
                label_knee.after(5000, on_after)                                                               # turns entry label text back to black after 5 seconds 
            
            elif entry_ankle.get() == '' or not entry_ankle.get().isdigit():                                   # if entry is empty or isn't a digit, it will pop a error and display a red label and warning
                label_warning.config(text='Invalid Entry')                                                     # warning label is set to display this error message
                label_ankle.config(fg='red')                                                                   # turns entry label foreground (text) as red to "pop"
                label_ankle.after(5000, on_after)                                                              # turns entry label text back to black after 5 seconds 
            
            else:
# If successful input, it will turn all entry labels back to black
                label_warning.config(text='')
                label_FName.config(fg='black')
                label_Address.config(fg='black')
                label_Zip.config(fg='black')
                label_Email.config(fg='black')
                label_Phone.config(fg='black')
                label_shoulder.config(fg='black')
                label_hip.config(fg='black')
                label_knee.config(fg='black')
                label_ankle.config(fg='black')
# On successful input, it will get the values of the entry fields as string, calls the product_request function which will open a new window containing a successful message and order information
                product_request(entry_FName.get(), entry_Address.get(), entry_Zip.get(), entry_Email.get(), entry_Phone.get(), entry_shoulder.get(), entry_hip.get(), entry_knee.get(), entry_ankle.get())
# This function is called during a error event, returning the warning label to empty to hide itd and the label text back to black   
        def on_after():
            label_warning.configure(text='')
            label_FName.configure(fg='black')
            label_Address.configure(fg='black')
            label_Zip.configure(fg='black')
            label_Email.configure(fg='black')
            label_Phone.configure(fg='black')
            label_shoulder.configure(fg='black')
            label_hip.configure(fg='black')
            label_knee.configure(fg='black')
            label_ankle.configure(fg='black')
 # This function will clear all fields which will erase the default text and labels back to black       
        def clear_fields():
           entry_FName.delete(0, END)
           entry_Address.delete(0, END)
           entry_Zip.delete(0, END)
           entry_Phone.delete(0, END)
           entry_Email.delete(0, END)
           entry_shoulder.delete(0, END)
           entry_hip.delete(0, END)
           entry_knee.delete(0, END)
           entry_ankle.delete(0, END) 
           label_warning.config(text='')
           label_FName.config(fg='black')
           label_Address.config(fg='black')
           label_Zip.config(fg='black')
           label_Email.config(fg='black')
           label_Phone.config(fg='black')
           label_shoulder.config(fg='black')
           label_hip.config(fg='black')
           label_knee.config(fg='black')
           label_ankle.config(fg='black')      
# This creates the banner frame at the top of the window, created with a drawn border
        frame_banner = tk.Frame(self, highlightbackground="black", highlightthickness=1)
        self.image_MainBanner = tk.PhotoImage(file='zimmer_banner_4.png')
        self.labelMainBanner = tk.Label(frame_banner, image=self.image_MainBanner, width=600, height=145)             # banner for application
        self.labelMainBanner.pack(expand=True, fill='both')
        frame_banner.pack(side='top')                                                                                  # packs it to the top of the window
# This creates the main frame that will contain the bottom, left, and right frames, created with a background window color variable and drawn border
        main_frame = tk.Frame(self, bg=window_bg_color, highlightbackground="black", highlightthickness=0.5)
# This creates the bottom frame to hold the button frame, created with a background window color variable
        frame_bottom = tk.Label(main_frame, bg=window_bg_color, width=600, height=80)
# This creates the button frame at the bottom, this carries over the window aesthetic from the other windows and holds buttons in the same space at the bottom of window
        frame_button = tk.Frame(frame_bottom, bg=window_bg_color)
# This set of code creates the switch window buttons with button color carried over from other windows, contains duo commands to switch windows
        switch_window_button = tk.Button(frame_button, text="Go to the Product Page", width=17, bg=button_color, command=lambda: controller.show_frame(ProductPage),)
        switch_window_button.pack(side="left")
        switch_window_button = tk.Button(frame_button, text="Go to the Main Page", width=17, bg=button_color, command=lambda: controller.show_frame(MainPage),)
        switch_window_button.pack(side="right")
        self.button_quit = tk.Button(frame_button, text = 'Quit', fg='red', bg=button_color, command = self.quit)       # quit button for application
        self.button_quit.pack(side='bottom', padx=5)                                                                    # packed to bottom, between window buttons
        frame_button.pack(side='bottom')                                                                                # packs button frame to the bottom of bottom frame
        frame_bottom.pack(fill='both', side='bottom', expand=True, padx=0, pady=0)                                      # packs bottom frame to bottom 

### I had empty space because I couldn't figure out what to do with the labels and entries, I didn't want two windows with large fields so I slapped on a picture to make it look more appealing?

# This creates the left banner frame, this was used to create a picture of a building location just to dress up empty space in the window
        main_left_frame = tk.Frame(main_frame, bg=window_bg_color)
        self.image_SideBanner = tk.PhotoImage(file='zimmer_side_banner_1.png')
        self.imageSideBanner = tk.Label(main_left_frame, image=self.image_SideBanner, width=200, height=330, highlightbackground="black", highlightthickness=1)
        self.imageSideBanner.pack(fill='both', expand=True)
        main_left_frame.pack(side='left', fill='y', expand=True, padx=10, pady=30)                                     # packs the frame to the left, filling empty space
# This creates the right frame to contain label frame and entry frame with white background and drawn borders
        main_right_frame = tk.Frame(main_frame, bg='white', highlightbackground="black", highlightthickness=1)
        label_Title = tk.Label(main_right_frame, text='Please provide ordering information', bg=button_color)
        label_Title.pack(fill='x')
# This creates label frame contained by the main right frame, it has a white background and a drawn border. It contains all the labels for the entry fields along with a empty label for warning/errors
        main_label_frame = tk.Frame(main_right_frame, bg='white', highlightbackground="black", highlightthickness=1)
        # label
        label_FName = tk.Label(main_label_frame, text='FULL NAME:', bg='white')
        label_FName.pack(padx=0, pady=5, anchor='w')
        # label
        label_Address = tk.Label(main_label_frame, text='ADDRESS:', bg='white')
        label_Address.pack(padx=0, pady=5, anchor='w')  
        # label   
        label_Zip = tk.Label(main_label_frame, text='ZIP:', bg='white')
        label_Zip.pack(padx=0, pady=5, anchor='w')
        # label
        label_Email = tk.Label(main_label_frame, text="EMAIL:", bg='white')
        label_Email.pack(padx=0, pady=5, anchor='w')
        # label
        label_Phone = tk.Label(main_label_frame, text='PHONE NUMBER:', bg='white', border=0)
        label_Phone.pack(padx=0, pady=5, anchor='w')
        # label
        label_Part = tk.Label(main_label_frame, text='Product Available', bg=window_bg_color)          # set the background to background window color to make it pop out
        label_Part.pack(padx=0, pady=5, anchor='w')
        # label
        label_shoulder = tk.Label(main_label_frame, text='Shoulder:', bg='white')
        label_shoulder.pack(padx=0, pady=5, anchor='w')
        # label
        label_hip = tk.Label(main_label_frame, text='Hip Stem:', bg='white')
        label_hip.pack(padx=0, pady=5, anchor='w')
        # label
        label_knee = tk.Label(main_label_frame, text='Total Knee:', bg='white')
        label_knee.pack(padx=0, pady=5, anchor='w')
        # label
        label_ankle = tk.Label(main_label_frame, text='Ankle:', bg='white')
        label_ankle.pack(padx=0, pady=5, anchor='w')
        # warning label
### This was a idea that someone chimmed in during a discord call, I had a few issues packing it perfectly but I believe it came out great along with the other functions
        label_warning = tk.Label(main_label_frame, text='', bg='white', fg='red')                      # set to empty, white background to hide it, red when it shows during error event
        label_warning.pack(padx=0, pady=5, expand=True, fill='both')
        label_warning.after(5000, on_after)                                                            # calls on_after function to turn it to empty, hiding it again
        ## end of the labels for this frame
        main_label_frame.pack(side='left', fill='both')                                                # packs to the left of the entry frame
# This creates the entry frame with a white background and drawn border
        main_entry_frame = tk.Frame(main_right_frame, bg='white', highlightbackground="black", highlightthickness=1)

###------------------------------------------------------------------------------------------------------------------------------###
### For the entry fields, I realized during the tail end of developing this that formatting of phone and zip could be a problem.
### After searching some other similar screens, I noticed that they contained ghost text explaining what that text is and how the values should be formatted so I carried that over into this
###------------------------------------------------------------------------------------------------------------------------------###

# This block of code creates the entry fields with default text already in the field, default text that will erase when selected, I forgot to make the text italic before erasing
        # entry
        entry_FName = tk.Entry(main_entry_frame, width=35)
        entry_FName.pack(padx=0, pady=5)
        entry_FName.insert(tk.END,'"Last, First"')                                                    # this inserts string into entry field for formatting purposes
        entry_FName.bind("<Button-1>", lambda e: entry_FName.delete(0, tk.END))                       # this binds the event of mouse button 1 into deleting the default text when the entry field is selected by the mouse
        # entry
        entry_Address = tk.Entry(main_entry_frame, width=35)
        entry_Address.pack(padx=0, pady=7)
        entry_Address.insert(tk.END,'"Street, City, State"')                                          # this inserts string into entry field for formatting purposes
        entry_Address.bind("<Button-1>", lambda e: entry_Address.delete(0, tk.END))                   # this binds the event of mouse button 1 into deleting the default text when the entry field is selected by the mouse
        # entry
        entry_Zip = tk.Entry(main_entry_frame, width=35)
        entry_Zip.pack(padx=0, pady=5)
        entry_Zip.insert(tk.END,'"#####"')                                                            # this inserts string into entry field for formatting purposes
        entry_Zip.bind("<Button-1>", lambda e: entry_Zip.delete(0, tk.END))                           # this binds the event of mouse button 1 into deleting the default text when the entry field is selected by the mouse
        # entry
        entry_Email = tk.Entry(main_entry_frame, width=35)
        entry_Email.pack(padx=0, pady=5)
        entry_Email.insert(tk.END,'"example@example.com"')                                             # this inserts string into entry field for formatting purposes
        entry_Email.bind("<Button-1>", lambda e: entry_Email.delete(0, tk.END))                        # this binds the event of mouse button 1 into deleting the default text when the entry field is selected by the mouse
        # entry
        entry_Phone = tk.Entry(main_entry_frame, width=35)
        entry_Phone.pack(padx=0, pady=5)
        entry_Phone.insert(tk.END,'"###-###-####"')                                                    # this inserts string into entry field for formatting purposes
        entry_Phone.bind("<Button-1>", lambda e: entry_Phone.delete(0, tk.END))                        # this binds the event of mouse button 1 into deleting the default text when the entry field is selected by the mouse
### During packing, I had issues lining up entry with labels so I created this declaration as a reminder that size is required for implants
        # label
        label_Empty_Space = tk.Label(main_entry_frame, width=35, text="---Size Determined on Customer Contact---", bg='white')
        label_Empty_Space.pack(padx=0, pady=5, fill='both')
        # entry
        entry_shoulder = tk.Entry(main_entry_frame, width=35)
        entry_shoulder.pack(padx=0, pady=6, fill='y')
        # entry
        entry_hip = tk.Entry(main_entry_frame, width=35)
        entry_hip.pack(padx=0, pady=6, fill='y')
        # entry
        entry_knee = tk.Entry(main_entry_frame, width=35)
        entry_knee.pack(padx=0, pady=5, fill='y')
        # entry
        entry_ankle = tk.Entry(main_entry_frame, width=35)
        entry_ankle.pack(padx=0, pady=7, fill='y')
# This creates the two buttons for the order validation and window creation and a clear button for any issues or to wipe out the default text
        order_button = tk.Button(main_entry_frame, text="Product Order", bg=button_color, height=2, width=10, command=order_validation)
        order_button.pack(padx=5, pady=5, fill='both')                                                   # packed first so it sits above the clear button
        clear_button = tk.Button(main_entry_frame, text='Clear Entry Fields', bg=button_color, height=2, width=10, command=clear_fields)
        clear_button.pack(padx=5, pady=5, fill='both')
        ## end of entries for entry frame
        main_entry_frame.pack(side='right', expand=True, fill='both')                                     # packs the frame to the right of the label frame                                                                       
        ## end of right frame
        main_right_frame.pack(side='right', expand=True, fill='both')                                     # packs the frame containing product and contact fields to the right of the picture location frame                                                                 
        ## end of main frame 
        main_frame.pack(expand=True, fill='both')

## This calls the main window class and starts the application in a never ending loop            
if __name__ == "__main__":
    ZBapp = windows()
    ZBapp.mainloop()


### ideas-coding-options
# drop down list? ----ugly as crap
''' optionbox for drop down list
            data=[
        'Fort Wayne', 
        'Indianapolis', 
        'South Bend', 
        'Gary', 
        'Warsaw'
         ]
        def boxtext(new_value):
                display.config(text = data[new_value])
        var = tk.StringVar()
        var.set('State')
        p = tk.OptionButton(main_label_frame, var, *data, command=boxtext)
        p.pack()
        display = tk.Label(main_label_frame, relief='flat')
        display.pack(padx=0, pady=5, anchor='w')
'''