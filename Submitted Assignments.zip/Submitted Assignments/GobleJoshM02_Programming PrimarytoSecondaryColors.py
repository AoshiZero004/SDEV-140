"""
    This is a program that takes user input of primary colors and displays what secondary color would appear after selecting these colors. 
    If the user doesn't input a valid color, the program will return a error message.
    Programming PrimarytoSecondaryColors.py
    Joshua Goble  - 8/29/2023
"""
endCount = 0
# When you mix red and blue, you get purple.
# When you mix red and yellow, you get orange.
# When you mix blue and yellow, you get green.
if endCount == 0: # checks condition at start of loop and each time loop repeats due to invalid input, I am working on refining this technique 
    print("Please input primary colors to get a secondary color.") # print statement to explain user input 
while endCount != 1: # Loop condition, if endCount is 1, it will exit loop. If it is 0, it will contiune to ask user till valid inputs are done
# user input section
    color1 = input("Enter your first primary color please: ").lower() # I spent three hours trying to figure out how to alter input so I don't get errors from user input
    color2 = input("Enter your second primary color please: ").lower() # .lower() does the trick, it returns the input as lower case so I don't have to worry about user input issues
# print(color1) troubleshooting code to see if .lower() works like it says
# print(color2) troubleshooting code to see if .lower() works like it says
# Seconday Color Section: Purple 
    if (color1 == "red" and color2 == "blue") or (color1 == "blue" and color2 == "red"): # checks colors to see if they match to make this secondary color section
        print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of purple.") # print statement for color mixing
        endCount = 1 # exit condition is met after valid inputs
#elif (color1 == "Red" and color2 == "Blue") or (color1 == "Blue" and color2 == "Red"): --- This code is redundant after discovering .lower()
#    print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of purple.") --- This code is redundant after discovering .lower()
#elif (color1 == "RED" and color2 == "BLUE") or (color1 == "BLUE" and color2 == "RED"): --- This code is redundant after discovering .lower()
#    print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of purple.") --- This code is redundant after discovering .lower()
# Seconday Color Section: Green
    elif (color1 == "blue" and color2 == "yellow") or (color1 == "yellow" and color2 == "blue"): # checks colors to see if they match to make this secondary color section
        print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of green.") # print statement for color mixing
        endCount = 1 # exit condition is met after valid inputs
#elif (color1 == "Blue" and color2 == "Yellow") or (color1 == "Yellow" and color2 == "Blue"): --- This code is redundant after discovering .lower()
#    print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of green.") --- This code is redundant after discovering .lower()
#elif (color1 == "BLUE" and color2 == "YELLOW") or (color1 == "YELLOW" and color2 == "BLUE"): --- This code is redundant after discovering .lower()
#    print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of green.") --- This code is redundant after discovering .lower()
# Seconday Color Section: Orange
    elif (color1 == "yellow" and color2 == "red") or (color1 == "red" and color2 == "yellow"): # checks colors to see if they match to make this secondary color section
        print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of orange.") # print statement for color mixing
        endCount = 1 # exit condition is met after valid inputs
#elif (color1 == "Yellow" and color2 == "Red") or (color1 == "Red" and color2 == "Yellow"): --- This code is redundant after discovering .lower()
#    print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of orange.") --- This code is redundant after discovering .lower()
#elif (color1 == "YELLOW" and color2 == "RED") or (color1 == "RED" and color2 == "YELLOW"): --- This code is redundant after discovering .lower()
#    print("When you mix the primary colors of", str(color1), "and", str(color2) + ",", "you will get a secondary color of orange.") --- This code is redundant after discovering .lower()
# ending section
    else: 
        print("You didn't input the two primary colors correctly.") # error statement if user input is invalid
else: 
    print("Thank you for your input.") # thank you statement to conclude user input and loop


