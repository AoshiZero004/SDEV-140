"""
    MO2 Programming Assignment - N Factorial Input
    User inputs a non-negative integer and the program will loop to calulate the factorial of that inputted number.
    Joshua Goble  - 9/2/2023
"""

userInteger = input("Please input a positive integer to be calculated: ") # input that is convered to integer for calculation purposes
nFactor = 1 # this initializes the factoral value before looping
while True: # while loop to ask for a valid input
    if (userInteger.isdigit()): # check condition for integer input
        userInt = int(userInteger) # this sets userInteger as a integer variable
        userInt_output = str(userInteger) # output statement after while loop completes
        break # break condition to enter next part of program when successful
    else: 
       print("Incorrect input. Please input a positive integer to be calculated: ") # error statement
       userInteger = input("Please input a positive integer to be calculated: ") # additional input statement till valid input
if userInt < 0: # output statement when invalid input is recieved 
    print("Incorrect input. Please input a positive integer to be calculated: ") # error statement
while userInt > 1: # when the user input is above one, loop repeats till factorial is found
    nFactor = nFactor * userInt # this multiplies against the user inputted number in while loop till user input reaches one thus ending the calculations to find factorial 
    userInt = userInt - 1 # this reduces the user input till 1 while doing calcuations to find factorial
    print(str(userInt), " x ", nFactor) # print statement for user while program loops to find factorial
print("You inputted", userInt_output,"and the factorial of this number is", str(nFactor) + ".") # print statement for user with found factorial

         
