'''
M07 Programming Assignment - Class Demostration.py
    Client program that uses Employee class and ProductionWorker subclass, Person class and Customer subclass
    Joshua Goble 10/8/2023
    call program with classes. imported
'''
import M07_Programming_Assignment_Classes # program containing classes
def main():
    #create production worker object
    newName = '' # variable
    newNumber = '' # variable
    newShift = 0 # variable
    newHrRate = 0.0 # variable
    
    newName = input('Please provide a name: ') # input statement
    newNumber = input('Please provide a new ID number: ') # input statement
    newShift = int(input('Please provide the current shift: ')) # input statement
    newHrRate = float(input('Please provide the new hourly rate: ')) # input statement

    ActWorker = M07_Programming_Assignment_Classes.ProductionWorker(newName, newNumber, newShift, newHrRate) # creating instance of ActWorker
    
    # display all fields after update to verify correct
    print('Name   ', ActWorker.get_name()) # test accessors
    print('Number    ', ActWorker.get_number()) # gets value using new set of data for instance of ActWorker
    print('Shift    ', ActWorker.get_shift())
    print('Rate    ', ActWorker.get_hrRate())
    print('')
main()