'''
M06 Programming Assignment - GUI for F from-to C temperature conversion.py
This program takes input from the user to converest the temperature to either fahrenheit and celsius and displays the number to the user
Joshua Goble 10/8/2023

'''

from breezypythongui import EasyFrame # imports easyframe 

#F=0 outdated code 
#C=0
#result=0

class TempConvert(EasyFrame): #creates class 
    def __init__(self): #set initial state
        EasyFrame.__init__(self, title="Temperature Converstion") #creates window with title
        self.addLabel(text='Please input the tempature to be calculated: ', row=0, column=0, columnspan=2) # create label for user
        self.inputField = self.addIntegerField(value=0, row=0, column=1, width=10, columnspan=2) # adds input field to use integer from user
        self.addButton(text='Convert: C to F', row=1, column=0, columnspan=2, command=self.C_to_F) #adds button to activate function to convert input
        self.addButton(text='Convert: F to C', row=1, column=2, columnspan=2, command=self.F_to_C) #adds button to activate function to convert input
        self.labelConverted = self.addLabel(text="Converted to: ", row=2, column=0, columnspan=2) # adds label for user output
        self.outputField = self.addFloatField(value=0.0, row=2, column=1, columnspan=3, state='readonly') # adds field to show user output
    def C_to_F(self):
        try: # tries user input against conditions and sends error if incorret input 
            C_input = self.inputField.getNumber() # takes value from input field
            F_user = (9/5 * C_input) + 32 # calucaltion to get F number
            self.labelConverted['text'] = 'Converted C to F' #sets label to string
            self.outputField.setNumber(F_user) # sets output field to calculated number for user
            #return F_user 
        except ValueError: # sends error message to user 
            self.messageBox(title='Error', message='Must input a integer!') # tells user they inputted incorrectly
    def F_to_C(self): 
        try: # tries user input against conditions and sends error if incorret input 
            F_input = self.inputField.getNumber() # takes value from input field
            C_user= 5/9 * (F_input-32) # calucaltion to get F number
            self.labelConverted['text'] = 'Converted F to C' #sets label to string
            self.outputField.setNumber(C_user) # sets output field to calculated number for user
            #return C_user
        except ValueError: # sends error message to user 
            self.messageBox(title='Error', message='Must input a integer!') # tells user they inputted incorrectly
def main():  # defines main and starts a ininfite loop
    TempConvert().mainloop()
# executes the main() module
if __name__=="__main__":
    main()