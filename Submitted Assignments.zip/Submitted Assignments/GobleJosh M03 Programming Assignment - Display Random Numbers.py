'''
GobleJosh M03 Programming Assignment - Display Random Numbers.py
Joshua Goble 9/10/2023
This program will take user input to specify a random assortment of numbers that will be written into 
a file and displayed for the user 
'''

import random # built in pseudorandom number generation function in python
rFile = open("RandomResults.txt", "w") # this opens a text file located at the python script folder
userInput = 0 # setting variable to 0
userInput = input("Enter the amount of numbers to be written: ") # user input to set how many lines of numbers will be written/read
if userInput.isdigit() is not True: # checks if input is a digit 
    print("This input is incorrect.") # error statement
    userInput = input("Enter the amount of numbers to be written: ").lower() # another attempt for valid input
else: 
    for i in range(int(userInput)): # for loop that will contiune based on how user specify input
        randResults = random.randint(1, 500) # sets randResults variable to random int function
        rFile.write(str(randResults)) # writes string of random integers to text file
        rFile.write("\n") # makes the next integer move to the next line for formatting
        #print(randResults) # debugging statement
rFile.close() # closing the file after writting

def main(): # using modules for displaying results
    rFile = open("RandomResults.txt", "r") # opening written file to be read into console
    rCount = 1 # count for displaying the indivual random numbers
    tCount = 0 # total count for displaying how many numbers were specified
    randNum = 0 # variable to be displayed when printing, overwritten by each line in text file
    for line in rFile: # for loop that counts till out of lines in text file
            randNum = int(line) #  variable that is used to display the random numbers
            print("Number", rCount, ":", randNum) # print statement including number count and random number
            rCount += 1 # counter
            tCount += 1 # counter
    rFile.close() # closing the file after reading
    print("Your total count of random numbers was", tCount) # end of program message to be printed telling user how many numbers they specified
main()

