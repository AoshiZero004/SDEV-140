'''
Goble Josh M05 Programming Assignment - Sales Tax Report.py
This program will take a monthly sales total from user and report the monthly sales total, state tax, county tax, and the final total tax.
Joshua Goble 9/28/2023
'''

def main():
    salesBeforeTax = GetMonthlySales() # call to input the function
    stateTaxRate = 0.05 # 5%
    countyTaxRate = 0.025 # 2.5%
    stateTax = salesBeforeTax * stateTaxRate # calculating state tax
    countyTax = salesBeforeTax * countyTaxRate # calculating county tax
    totalTax = stateTax + countyTax # calculating total tax
    print(f'The monthly sales total for this month is ={salesBeforeTax:^7.2f}') # print statement
    print(f'The State sales Tax for this monthly amount is ={stateTax:^7.2f}') # print statement
    print(f'The County sales tax for this monthly amount is ={countyTax:^7.2f}') # print statement
    print(f'The Total sales tax for this amount is ={totalTax:^7.2f}') # print statement
def GetMonthlySales(): # module to input monthly sales  
    while True: # while loop that breaks when input is correct
        try:
            monthlySalesBeforeTaxinput = input("Enter the total monthly sales before taxes: ") # input statement
            if monthlySalesBeforeTaxinput.isdigit(): # checks if input is a valid number, does not accept characters or negative values
                monthlySalesBeforeTax = float(monthlySalesBeforeTaxinput)   # turns valid input into floating number
                return monthlySalesBeforeTax # returns the program to contiune next step    
            elif monthlySalesBeforeTaxinput.replace(".", "").isnumeric(): # checks string if replacing the period with nothing makes it numeric, if it does, it will turn the number into a float
                monthlySalesBeforeTax = float(monthlySalesBeforeTaxinput)
                return monthlySalesBeforeTax
            else: # else statement for invalid input
                print("Input must be a valid total for this program.") # error output
        except ValueError: # output for invalid number
            print("Input must be a valid floating number.") # error output
main()