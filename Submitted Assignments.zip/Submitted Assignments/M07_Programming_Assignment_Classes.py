'''
M07 Programming Assignment - Create class Person and subclass Customer.py
        --Contain class Employee and Subclass ProductionWorker, class Person and cubclass Person--
        Employee: Name and employee number
        ProductionWorker: Subclass of Employee with additional shift hourly rate
        Person: Name, Address, Number
        Customer: Number
        Mailing List: True/False
        Joshua Goble 10/8/2023
'''
class Person: # creates a class as Person
    def __init__(self, name, address, telenumber): # sets initial state with name, address, number parameters to be referenced
        self.name = name # instance variable within class
        self.address = address #instance variable within class
        self.telenumber = telenumber #instance variable within class
    def get_name(self): # methon within class
        return self.name # returns name
    def get_address(self): # methon within class
        return self.address # returns address
    def get_telenumber(self): # methon within class
        return self.telenumber # returns address
    def set_name(self, name): # methon within class
        self.name = name # sets self.name as name when called
    def set_address(self, address): # methon within class
        self.address = address # sets self.address as address when called
    def set_telenumber(self, telenumber): # methon within class
        self.telenumber = telenumber # sets self.number as number when called

class Customer(Person): # creates class as Customer which is a subclasss of Person
    def __init__(self, name, address, telenumber, ID, mailinglist): # sets initial state with number and mailing list as parameters to be referenced
        Person.__init__(self, name, address, telenumber) # executes __init__ of superclass
        self.ID = ID # instance variable within class
        self.mailinglist = mailinglist # instance variable within class
    def get_ID(self): #method within class
        return self.ID # returns ID
    def get_mailinglist(self): # method witnin class
        if self.mailinglist == True:
            return "They are on the mailing list."# returns maining list response
        else:
            return "They are NOT on the mailing list."
    def set_mumber(self, ID): # method within class
        self.ID = ID # sets ID when called
    def set_mailinglist(self, mailinglist): # methond witin class
        self.mailinglist = mailinglist # sets list when called

class Employee:
    def __init__(self, name, number): # method - parameters
        self.name = name # instance variable
        self.number = number #state variable of Employee objects
    def get_name(self): # method - parameter | accessor to retrieve employee name
        return self.name
    def get_number(self): # method - parameter | 
        return self.number
    def set_name(self, name): # method - parameter | passes to main | metator method to update name
        self.name = name
    def set_number(self, number):
        self.number = number
class ProductionWorker(Employee): # class - parameter | defines subclass of superclass
    def __init__(self, name, number, shift, hrRate):
        Employee.__init__(self, name, number) # executes __init__ of superclass(Employee)
        self.shift = shift
        self.hrRate = hrRate # sets to parameter
    def get_shift(self):
        if self.shift == 1 or self.shift == 2:
            return self.shift # returns shift when conditions match
        else:
            print("This is a invalid shift number.") # error statement
    def get_hrRate(self):
        return self.hrRate # returns hrRate when called
    def set_shift(self, shift): # mutator methods to change states
        if self.shift == 1 or self.shift == 2:
            self.shift = shift # sets shift when conditions matched when called
        else:
            print("This is a invalid shift number.")     # error statement 
    def set_hrRate(self, hrRate):
        self.hrRate = hrRate # sets hrRate when called
