'''
This program takes user input of a series of numbers without spaces between each digit and 
will add them and display the sum for the user.
GobleJoshua M03 Programming Assignment - Sum Input Digits.py
Joshua Goble 9/10/2023
'''


number = 0 
flag = 0 # loop exit condition
uInput = input("Enter a series of integers to be calculated: ").lower() #.lower() to control input for exit
inputList = list() # defines empty list 
while flag == 0: # if the input is incorrectly, loop will loop till input is valid
    if uInput.isdigit() is not True: # checks if input is a digit 
        print("This input is incorrect.") # error statement
        uInput = input("Enter a series of integers: ").lower() 
    else: 
        flag = 1 # this sets the exit loop condition to true 
        for number in uInput:
            for num in number.split(): # splits input into a list
                if num.isnumeric(): # checks if num is a numeric value
                    inputList.append(int(num)) # this adds the value as a integer into list
print("You inputted this list", inputList) # this prints the list for user
print("The sum of that list is", sum(inputList)) # this prints sum of the list for user
