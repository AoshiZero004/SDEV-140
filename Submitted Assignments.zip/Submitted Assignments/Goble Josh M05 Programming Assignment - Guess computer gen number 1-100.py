'''
Goble Josh M05 Programming Assignment - Guess computer gen number 1-100.py
This program will generate a random number for the user in the range of 1 to 100 and ask the user to guess it. If it is too high or low,
the program will display a message but if the user guesses the number, the program will congratule and start over.
Joshua Goble 9/28/2023
'''
import time
played = 0 # setting played to 0 at start of program
def main(): # main module
    global played # setting played as a global variable
    played += 1 # adds to counter each played game
    import random # import random python function
    generatedNumber = random.randint(1, 100) # imported randon function 
    print("Gen # is ", generatedNumber) # debug ! turn off when using program properly
    numGuessed = Guess(generatedNumber) # this declares the variable after calling guess module using the generated number variable
    print("Good job, you were able to guess the number in", numGuessed, "total attempts.") # print statement for total attempts
    print("You didn't guess the correct number this total number of times: ", nonGuessed) # print statement for incorrect guesses
    while True:
        anotherTry = input("Would you like to try again? ").lower() # input statement asking user if they want to attempt another game
        if anotherTry == 'yes': # if statement that will start another game if user inputs yes or y
            main() # calls module again
        elif anotherTry == 'no':
            print("You played for a total number of games: ", played) # ending statement telling user how many games they played
            print("Thank you for playing.") # ending statement
            time.sleep(7) # delays ending the program for 7 seconds so the user can see their total number of games played
            quit() # exits the program when user input no
        else:
            print("Program requires a yes or no answer.")
def Guess(genNum): # user input module
    global nonGuessed # call global on nonguessed variable to be used in print statement
    nonGuessed = 0 # setting to 0 to be counted up based on incorrect attempts
    def notGuessed(): # incorrect attempt 
        global nonGuessed # # call global on nonguessed variable to be used in print statement
        nonGuessed += 1 # when this is called, it will add to the counter when the user is too high or too low
    numGuessed = 0 # setting variable to 0
    nonGuessed = 0 # setting variable to 0
    userGuess = 0 # setting variable to 0
    error = 0 # setting variable to 0
    print("Please input what you think the number could be between 1 and 100! ") # print statement at start of attempts
    while genNum != userGuess: # while loop till user guesses the correct number
        counter = False # counter for while loop till correct input is put in
        userGuess = input("Enter your next guess: ") # user input for guessing game
        while counter != True: # while loop for user input to validate input
            if userGuess.isnumeric(): # checks string in order to make number float
                userGuess = float(userGuess) # if string is a valid number, turns into float for guessing game
                numGuessed += 1 # counter for total attempts
                counter = True # sets to true when condition is met, resets at loop start
            else:
                print("Please input a valid number between 1 and 100!") # error statement
                error += 1 # debug
                userGuess = input("Enter your next guess: ") # error message       
        if userGuess > genNum: # if statement if user is too high
            print("Your guess was too high. Please try again.") # print statement
            notGuessed() # calls for incorrect attempt counter to add up 1
        elif userGuess < genNum: # if statement if user is too low
            print("Your guess was too low. Please try again.") # error message
            notGuessed() # calls for incorrect attempt counter to add up 1
        else:  
            return numGuessed # returns when the user guesses the number
        
main() # calls main module
        
                 
        



