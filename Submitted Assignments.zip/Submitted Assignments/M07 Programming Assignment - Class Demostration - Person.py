'''
M07 Programming Assignment - Class Demostration - Person.py
    Client program that uses Employee class and ProductionWorker subclass, Person class and Customer subclass
    Joshua Goble 10/8/2023
    call program with classes. imported
'''
import M07_Programming_Assignment_Classes # program containing classes
def main():
    #create production worker object
    PersonCust = M07_Programming_Assignment_Classes.Customer('Joe', '1234Street', '321-123-1234', 'ID6479', False)  # takes the parameters and sets them using classes 
 
    # display Customer after __init__
    print('Name :  ', PersonCust.get_name()) # test accessors
    print('Address:    ', PersonCust.get_address())
    print('Telephone #:   ', PersonCust.get_telenumber())
    print('Customer ID:        ', PersonCust.get_ID())
    print('Mailing List:    ', PersonCust.get_mailinglist())
    print('')

main()