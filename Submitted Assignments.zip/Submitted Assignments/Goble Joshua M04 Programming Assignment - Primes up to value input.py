'''
Goble Joshua M04 Programming Assignment - Primes up to value input.py
This program will ask the user for a number and will find the prime numbers up to that value
Joshua Goble 9/15/2023

Author Note: I got up to 50,000,000 with my CPU maxing out operating temperature for 156 seconds. I would stay under 5,000 for your own sake unless you have extreme water cooling like me.
'''

count = 0
primedList = [] # List array to contain prime numbers to be displayed
compedList = [1] # List array to contain composite numbers to be displayed
fullList = [] # list array to contain all values up to user input
def userInput(): # input module to validate input from user
    count = 0
    prime = input("Input a integer greater than 1 to find the prime numbers up to that value: ") # user input
    while count != 1: # main count to break loop, still working on these error loops
        if prime.isdigit() is not True: # checks if input is a string
        #print("Error") # error statement for invalid input
            prime = input("Please input a valid integer greater than 1: ") # user input
        while prime.isdigit() is True: # checks if input is greater or less than 1
            primed = int(prime) # if it passes the digit check, it becomes a integer
            if primed < 2: # if it is lower than 2, it will loop till input is valid
                prime = input("Please input a valid integer greater than 1: ") # user input
            else:
                for i in range(1, primed+1, 1): # this builds the list up to the valid input from user
                    fullList.append(i) # appends the list 
                displayPrimes(primed) # this calls the display module when it is done loops list
                count = 1 # loop exit condition
                break
        
def displayPrimes(fullList): # module that builds the list arrays to be displayed for users
    import math # importing python module
    for i in range(2, fullList + 1): # for loop that starts at 2, loops while adding 1
        # print("1 For in", "i", i) - debugging code
        for j in range(2, int(i ** 0.5) + 1): # for loop that starts at 2, takes the integer of i, raises to the power of 1/2 and adds one, I was doing this reverse in my first attempt and kept having so many issues
            # print("2 For in", "i", i, "j", j) - debugging code
            if i%j == 0: # if statement that check of the remainer is equal to 0, it not, else statement is taken
                # isPrime = 'n' - I decided to leave this out as it would mess with old code
                compedList.append(i) # if requiremet is met, it adds it to the composite list
                # print("__CL", "i", i, "j", j) - debugging code
                break 
        else: # else statement if integer meets requirements
            # isPrime = 'y'- see above
            primedList.append(i) # if requiremet is met, it adds it to the prime list

        # print("reset") - debugging code

userInput()
print("This list of numbers are your numbers up to your inputted value:", fullList)
print("This list of numbers contains your composite numbers:", compedList)
print("This list of numbers contains your prime numbers:", primedList)


#turn square into while loop, if else where if does square till it cant then leaves loop[?]
# while loop for input, if input is not valid, stay in loop till valid


"""
do math, add to list prime or composite, than display to reduce lag?
"""
